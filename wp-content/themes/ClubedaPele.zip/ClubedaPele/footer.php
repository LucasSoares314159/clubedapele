<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<title> Clube da Pele</title>

	<!-- Required meta tasgs -->
    <meta <?php bloginfo('charset'); ?>>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap --> 
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url');?>/style.css">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url');?>/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url');?>/css/bootstrap.min.css">

	<!-- Font awesome --> 
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

	<!-- Fontes -->
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Parisienne" rel="stylesheet">

</head>


<div class="container-fluid contact">
	<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center contact-1">
				<i class="far fa-clock"></i> Seg-Sex: 9am - 17pm 
			</div>

			<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center contact-2">
				<i class="fab fa-whatsapp"></i> WhatsApp: (21) 9 9861-3596
			</div>

			<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center contact-3">
				<i class="far fa-envelope"></i> suporte@clubedapele.com
			</div>
	</div>
</div>

<div class="container" style="padding-bottom: -100px;">
	<div class="row">
		<div class="col-md-12 col-lg-12 col-xl-12 text-center newslatter-text">
			<!-- <h4>CADASTRE SEU EMAIL E RECEBA AS NOVIDADES ANTES DE TODO MUNDO</h4>
			<input type="email" name="email"><br> -->
			
			<!-- Web -->
			<div class="text-footer d-sm-none d-md-block d-none d-sm-block">
				<a href="https://www.instagram.com/clubedapele.oficial/"><i class="fab fa-instagram fa-3x" style="color: #FF8F8F;"></i></a>
				<p>2019 CLUBE DA PELE LTDA. <br> Rua Lemos Cunha nº 318, Icaraí - Niterói / RJ - CEP 24230-136</p>
			</div>

			<!-- Mobile -->
			<div class="text-footer-mob d-block d-sm-none d-none d-sm-block d-md-none">
				<a href="https://www.instagram.com/clubedapele.oficial/"><i class="fab fa-instagram fa-3x" style="color: #FF8F8F;"></i></a>
				<p>2019 CLUBE DA PELE LTDA. <br> Rua Lemos Cunha nº 318, Icaraí - Niterói / RJ - CEP 24230-136</p>
			</div>
		</div>		
	</div>
</div>

<!-- Script Bootstrap -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>